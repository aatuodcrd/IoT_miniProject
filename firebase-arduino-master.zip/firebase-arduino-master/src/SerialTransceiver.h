#include "modem/SerialTransceiver.h"
// Bring them into the base namespace for easier use in arduino ide.
using firebase::modem::SerialTransceiver;
